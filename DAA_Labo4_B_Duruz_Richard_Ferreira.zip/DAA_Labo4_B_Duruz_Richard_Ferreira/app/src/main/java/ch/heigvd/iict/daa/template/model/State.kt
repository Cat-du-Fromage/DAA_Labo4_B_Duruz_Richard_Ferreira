package ch.heigvd.iict.daa.template.model

enum class State {
    IN_PROGRESS, DONE
}