package ch.heigvd.iict.daa.lab4_b.models

enum class State {
    IN_PROGRESS, DONE
}