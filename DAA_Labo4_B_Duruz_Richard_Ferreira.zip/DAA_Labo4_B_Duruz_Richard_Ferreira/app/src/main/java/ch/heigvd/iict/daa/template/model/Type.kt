package ch.heigvd.iict.daa.template.model

enum class Type {
    NONE, TODO, SHOPPING, WORK, FAMILY
}