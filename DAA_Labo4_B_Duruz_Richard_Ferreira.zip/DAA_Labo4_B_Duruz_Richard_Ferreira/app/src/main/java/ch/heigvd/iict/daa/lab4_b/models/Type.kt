package ch.heigvd.iict.daa.lab4_b.models

enum class Type {
    NONE, TODO, SHOPPING, WORK, FAMILY
}